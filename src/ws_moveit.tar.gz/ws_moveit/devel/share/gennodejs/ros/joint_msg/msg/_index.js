
"use strict";

let joint_msg = require('./joint_msg.js');

module.exports = {
  joint_msg: joint_msg,
};
